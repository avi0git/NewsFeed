import React, { useState } from "react";
import "../styles/MessageShareModal.css";

const MessageShareModal = ({ post, onClose }) => {
  const [selectedRecipient, setSelectedRecipient] = useState("");

  const handleSend = () => {
    // Logic to send the post to the selected recipient
    alert(`Post shared with ${selectedRecipient}`);
    onClose();
  };

  return (
    <div className="message-share-modal">
      <div className="message-share-content">
        <h3>Share Post in Messages</h3>
        <label htmlFor="recipient">Choose recipient:</label>
        <input
          type="text"
          id="recipient"
          value={selectedRecipient}
          onChange={(e) => setSelectedRecipient(e.target.value)}
          placeholder="Enter recipient's name"
        />
        <div className="modal-actions">
          <button onClick={handleSend}>Send</button>
          <button onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default MessageShareModal;

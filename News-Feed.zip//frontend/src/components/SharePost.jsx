import React, { useState } from "react";
import MessageShareModal from "./MessageShareModal";

const SharePost = ({ post }) => {
  const [showMessageModal, setShowMessageModal] = useState(false);

  const handleCopyLink = () => {
    const postLink = `${window.location.origin}/post/${post.id}`;
    navigator.clipboard.writeText(postLink);
    alert("Link copied to clipboard!");
  };

  const handleShareInMessages = () => {
    setShowMessageModal(true);
  };

  return (
    <div className="share-post-options">
      <button onClick={handleCopyLink}>Copy Link</button>
      <button onClick={handleShareInMessages}>Share in Messages</button>

      {showMessageModal && (
        <MessageShareModal
          post={post}
          onClose={() => setShowMessageModal(false)}
        />
      )}
    </div>
  );
};

export default SharePost;

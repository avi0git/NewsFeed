import React from "react";
import "../styles/Sidebar.css";

function Sidebar() {
  return <aside className="sidebar">{/* Your sidebar content here */}</aside>;
}

export default Sidebar;

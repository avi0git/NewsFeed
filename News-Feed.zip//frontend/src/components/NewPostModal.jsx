import React, { useState } from "react";
import "../styles/NewPostModal.css";

const NewPostModal = ({ onClose, onSave }) => {
  const [content, setContent] = useState("");
  const [images, setImages] = useState([]);

  const handleSave = () => {
    if (content.trim() || images.length > 0) {
      onSave(content, images);
      setContent("");
      setImages([]);
    }
  };

  const handleImageChange = (e) => {
    setImages(Array.from(e.target.files));
  };

  return (
    <div className="modal">
      <div className="modal__content">
        <h2>Create New Post</h2>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="What's on your mind?"
        />
        <input type="file" multiple onChange={handleImageChange} />
        <div className="modal__actions">
          <button onClick={onClose} className="cancelButton">
            Cancel
          </button>
          <button onClick={handleSave} className="saveButton">
            Post
          </button>
        </div>
      </div>
    </div>
  );
};

export default NewPostModal;

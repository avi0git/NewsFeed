import React, { useState } from "react";
import "../styles/Post.css";
import SharePost from "./SharePost";

function Post({ post, onAddComment }) {
  const [upvoted, setUpvoted] = useState(post.upvoted);
  const [upvotes, setUpvotes] = useState(post.upvotes);
  const [commentText, setCommentText] = useState("");
  const [showComments, setShowComments] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isShareOpen, setIsShareOpen] = useState(false); // State to toggle share options

  const handleUpvoteClick = () => {
    setUpvotes(upvotes + (upvoted ? -1 : 1));
    setUpvoted(!upvoted);
  };

  const handleUpvote = async () => {
    try {
      await axios.patch(`/api/posts/${post._id}/upvote`); // Call backend API for upvote
      setUpvoted(!upvoted); // Toggle upvote in frontend
    } catch (error) {
      console.error(
        "Error upvoting:",
        error.response?.data?.message || error.message
      );
    }
  };

  const handleAddComment = async (commentText) => {
    try {
      const response = await axios.post(`/api/posts/${post._id}/comment`, {
        text: commentText,
      });
      setComments([...comments, response.data]); // Update comments in frontend
    } catch (error) {
      console.error(
        "Error adding comment:",
        error.response?.data?.message || error.message
      );
    }
  };

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (commentText.trim()) {
      onAddComment(post.id, commentText);
      setCommentText("");
    }
  };

  const handleNextImage = () => {
    if (post.images.length > 1) {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % post.images.length);
    }
  };

  const handlePrevImage = () => {
    if (post.images.length > 1) {
      setCurrentImageIndex(
        (prevIndex) => (prevIndex - 1 + post.images.length) % post.images.length
      );
    }
  };

  return (
    <div className="post">
      <div className="post__header">
        <div className="post__avatar">
          <img src="/assets/avatar.png" alt="User Avatar" />
        </div>
        <div className="post__info">
          <h4 className="post__author">{post.author}</h4>
          <p className="post__timestamp">Posted {post.timestamp}</p>
        </div>
      </div>
      <div className="post__content">
        <h2 className="post__title">{post.title}</h2>
        <p>{post.content}</p>

        {post.images.length > 0 && (
          <div className="post__images">
            <button
              className="post__imageNavButton prev"
              onClick={handlePrevImage}
              disabled={post.images.length <= 1}
            >
              &lt;
            </button>
            <img
              src={URL.createObjectURL(post.images[currentImageIndex])}
              alt={`Post image ${currentImageIndex}`}
              className="post__image"
            />
            <button
              className="post__imageNavButton next"
              onClick={handleNextImage}
              disabled={post.images.length <= 1}
            >
              &gt;
            </button>
          </div>
        )}
      </div>
      <div className="post__footer">
        <div className="post__actions">
          <span
            onClick={handleUpvoteClick}
            className={`post__upvote ${upvoted ? "upvoted" : ""}`}
          >
            ⬆
          </span>
          <span onClick={() => setShowComments(!showComments)}>🗨</span>
          <span
            onClick={() => setIsShareOpen(!isShareOpen)} // Toggle the share options
          >
            🔗
          </span>
        </div>
        <div className="post__stats">
          {upvotes} Upvotes • {post.comments.length} Comments
        </div>
      </div>
      {showComments && (
        <div className="post__comments">
          {post.comments.map((comment) => (
            <div key={comment.id} className="post__comment">
              {comment.text}
            </div>
          ))}
          <form onSubmit={handleCommentSubmit} className="post__commentForm">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Write a comment..."
            />
            <button type="submit">Post</button>
          </form>
        </div>
      )}

      {/* Show SharePost component if the 🔗 button is clicked */}
      {isShareOpen && <SharePost postId={post.id} />}
    </div>
  );
}

export default Post;

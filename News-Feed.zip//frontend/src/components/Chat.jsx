import React, { useState } from "react";
import "../styles/Chat.css";

const usersList = [
  { id: 1, name: "Avi" },
  { id: 2, name: "MyEasyPharma" },
  { id: 3, name: "Alex Johnson" },
];

const Chat = ({ onClose }) => {
  const [selectedUser, setSelectedUser] = useState(null);
  const [messages, setMessages] = useState({});
  const [currentMessage, setCurrentMessage] = useState("");

  const handleUserSelect = (user) => {
    setSelectedUser(user);
    if (!messages[user.id]) {
      setMessages((prev) => ({ ...prev, [user.id]: [] }));
    }
  };

  const handleSendMessage = () => {
    if (currentMessage.trim() && selectedUser) {
      setMessages((prev) => ({
        ...prev,
        [selectedUser.id]: [
          ...prev[selectedUser.id],
          { from: "me", text: currentMessage },
        ],
      }));
      setCurrentMessage("");
    }
  };

  return (
    <div className="chat">
      <div className="chat__header">
        <h2>Messages</h2>
        <button className="chat__closeButton" onClick={onClose}>
          Close
        </button>
      </div>
      <div className="chat__container">
        <div className="chat__userList">
          <h3>Chats</h3>
          {usersList.map((user) => (
            <div
              key={user.id}
              className={`chat__user ${
                selectedUser && selectedUser.id === user.id
                  ? "chat__user--selected"
                  : ""
              }`}
              onClick={() => handleUserSelect(user)}
            >
              {user.name}
            </div>
          ))}
        </div>
        <div className="chat__content">
          {selectedUser ? (
            <>
              <div className="chat__messages">
                {messages[selectedUser.id].map((msg, index) => (
                  <div
                    key={index}
                    className={`chat__message ${
                      msg.from === "me" ? "chat__message--fromUser" : ""
                    }`}
                  >
                    {msg.text}
                  </div>
                ))}
              </div>
              <div className="chat__input">
                <input
                  type="text"
                  placeholder="Type a message..."
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                />
                <button onClick={handleSendMessage}>Send</button>
              </div>
            </>
          ) : (
            <div className="chat__noSelection">
              Select a user to start chatting
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Chat;

import React, { useState } from "react";
import axios from "axios";
import "../styles/SignUpForm.modal.css";

const SignUpForm = ({ onSignUpComplete }) => {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // Mark the handleSubmit function as async
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Send the signup request to the backend
      const response = await axios.post("/api/users/signup", {
        username,
        email,
        password,
      });

      if (response.status === 201) {
        console.log("Signup successful:", response.data);
        onSignUpComplete(); // Call to close modal or perform post-signup actions
      }
    } catch (error) {
      console.error(
        "Error during signup:",
        error.response?.data?.message || error.message
      );
    }
  };

  return (
    <div className="signup-form">
      <form onSubmit={handleSubmit}>
        <label>
          Username:
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>
        <label>
          Password:
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
};

export default SignUpForm;
